function showInputLeft() { parent.leftnav.showInputLeft(); }
